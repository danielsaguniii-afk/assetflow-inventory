  </div><!-- /.page-content -->
</div><!-- /.main -->

<script>
// Live search filter for tables
document.querySelectorAll('.js-search').forEach(input => {
  input.addEventListener('input', function() {
    const q = this.value.toLowerCase();
    const tableId = this.dataset.table;
    document.querySelectorAll('#' + tableId + ' tbody tr').forEach(row => {
      const text = row.textContent.toLowerCase();
      row.style.display = text.includes(q) ? '' : 'none';
    });
  });
});

// Modal handling
document.querySelectorAll('[data-open-modal]').forEach(btn => {
  btn.addEventListener('click', () => {
    const modal = document.getElementById(btn.dataset.openModal);
    if (modal) modal.classList.add('open');
  });
});
document.querySelectorAll('.modal-close, .modal-overlay').forEach(el => {
  el.addEventListener('click', function(e) {
    if (e.target === this || this.classList.contains('modal-close')) {
      document.querySelectorAll('.modal-overlay').forEach(m => m.classList.remove('open'));
    }
  });
});
document.querySelectorAll('.modal').forEach(m => {
  m.addEventListener('click', e => e.stopPropagation());
});

// Confirm delete
document.querySelectorAll('.js-confirm').forEach(btn => {
  btn.addEventListener('click', function(e) {
    if (!confirm(this.dataset.msg || 'Are you sure?')) e.preventDefault();
  });
});
</script>
</body>
</html>
