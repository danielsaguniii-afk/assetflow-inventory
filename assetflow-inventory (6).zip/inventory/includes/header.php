<?php
ob_start();
if (session_status() === PHP_SESSION_NONE) {
    session_save_path(sys_get_temp_dir());
    session_start();
}
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/helpers.php';

$currentPage = basename($_SERVER['PHP_SELF'], '.php');

// Auth guard
if (empty($_SESSION['user']) && $currentPage !== 'login') {
    ob_end_clean();
    header('Location: login.php'); exit;
}
$sessionUser = $_SESSION['user'] ?? ['name' => 'Guest', 'role' => ''];
$userInitials = implode('', array_map(fn($w) => strtoupper($w[0]), explode(' ', trim($sessionUser['name']))));
$userInitials = substr($userInitials, 0, 2);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>AssetFlow — <?= ucfirst($currentPage) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Syne:wght@500;600;700&family=Instrument+Sans:wght@400;500&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
/* ── Reset & Base ── */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
:root {
  --bg:        #0e0f11;
  --surface:   #16181c;
  --surface2:  #1e2026;
  --border:    rgba(255,255,255,0.07);
  --border2:   rgba(255,255,255,0.13);
  --text:      #edeae4;
  --muted:     #7c7a85;
  --muted2:    #545260;
  --accent:    #c8ff57;
  --accent-d:  rgba(200,255,87,0.13);
  --danger:    #ff5f57;
  --danger-d:  rgba(255,95,87,0.13);
  --info:      #5ab4ff;
  --info-d:    rgba(90,180,255,0.12);
  --success:   #34d399;
  --success-d: rgba(52,211,153,0.12);
  --warn:      #fbbf24;
  --warn-d:    rgba(251,191,36,0.13);
  --radius:    10px;
  --sidebar-w: 240px;
  --font-head: 'Syne', sans-serif;
  --font-body: 'Instrument Sans', sans-serif;
  --font-mono: 'DM Mono', monospace;
}
html, body { height: 100%; }
body {
  font-family: var(--font-body);
  background: var(--bg);
  color: var(--text);
  display: flex;
  min-height: 100vh;
  font-size: 14px;
  line-height: 1.6;
}
a { color: inherit; text-decoration: none; }

/* ── Sidebar ── */
.sidebar {
  width: var(--sidebar-w);
  background: var(--surface);
  border-right: 1px solid var(--border);
  display: flex;
  flex-direction: column;
  position: fixed;
  top: 0; left: 0;
  height: 100vh;
  z-index: 100;
  padding: 0 0 1.5rem;
}
.sidebar-logo {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 1.4rem 1.25rem 1.2rem;
  border-bottom: 1px solid var(--border);
  margin-bottom: 0.75rem;
}
.logo-mark {
  width: 32px; height: 32px;
  background: var(--accent);
  border-radius: 8px;
  display: grid; place-items: center;
}
.logo-mark svg { width: 18px; height: 18px; }
.logo-text { font-family: var(--font-head); font-size: 16px; font-weight: 700; letter-spacing: -0.5px; }
.logo-text span { color: var(--accent); }

.nav-section { padding: 0.25rem 0.75rem 0.1rem; font-size: 10px; font-weight: 600; letter-spacing: 1.2px; text-transform: uppercase; color: var(--muted2); margin-top: 0.5rem; }
.nav-item {
  display: flex; align-items: center; gap: 10px;
  padding: 0.55rem 1.25rem;
  border-radius: 0;
  color: var(--muted);
  font-size: 13.5px;
  transition: color .15s, background .15s;
  cursor: pointer;
  position: relative;
}
.nav-item:hover { color: var(--text); background: rgba(255,255,255,0.04); }
.nav-item.active {
  color: var(--accent);
  background: var(--accent-d);
  font-weight: 500;
}
.nav-item.active::before {
  content: '';
  position: absolute;
  left: 0; top: 20%; bottom: 20%;
  width: 3px;
  background: var(--accent);
  border-radius: 0 3px 3px 0;
}
.nav-item svg { width: 17px; height: 17px; flex-shrink: 0; }

.sidebar-footer {
  margin-top: auto;
  padding: 0.75rem 1.25rem 0;
  border-top: 1px solid var(--border);
  font-size: 11.5px;
  color: var(--muted2);
}

/* ── Main ── */
.main {
  margin-left: var(--sidebar-w);
  flex: 1;
  display: flex;
  flex-direction: column;
  min-height: 100vh;
}
.topbar {
  background: var(--surface);
  border-bottom: 1px solid var(--border);
  padding: 0 2rem;
  height: 56px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  position: sticky; top: 0; z-index: 50;
}
.topbar-title { font-family: var(--font-head); font-size: 15px; font-weight: 600; }
.topbar-right { display: flex; align-items: center; gap: 12px; }
.topbar-user {
  width: 32px; height: 32px;
  border-radius: 50%;
  background: var(--accent-d);
  border: 1.5px solid var(--accent);
  display: grid; place-items: center;
  font-size: 12px; font-weight: 600; color: var(--accent);
}
.page-content { padding: 2rem; flex: 1; }

/* ── Components ── */
.page-header { display: flex; align-items: flex-end; justify-content: space-between; margin-bottom: 1.75rem; gap: 1rem; flex-wrap: wrap; }
.page-header h1 { font-family: var(--font-head); font-size: 22px; font-weight: 700; letter-spacing: -0.5px; }
.page-header p  { font-size: 13px; color: var(--muted); margin-top: 2px; }

/* Cards */
.cards-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 14px; margin-bottom: 1.75rem; }
.stat-card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  padding: 1.1rem 1.25rem;
}
.stat-card .label { font-size: 11.5px; color: var(--muted); text-transform: uppercase; letter-spacing: .8px; margin-bottom: 6px; }
.stat-card .value { font-family: var(--font-head); font-size: 26px; font-weight: 700; line-height: 1; }
.stat-card .sub   { font-size: 12px; color: var(--muted); margin-top: 5px; }
.stat-card.accent .value { color: var(--accent); }
.stat-card.danger .value { color: var(--danger); }
.stat-card.info   .value { color: var(--info); }
.stat-card.warn   .value { color: var(--warn); }

/* Table */
.table-wrap {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  overflow: hidden;
}
.table-toolbar {
  display: flex; align-items: center; justify-content: space-between;
  padding: 1rem 1.25rem;
  border-bottom: 1px solid var(--border);
  gap: 12px; flex-wrap: wrap;
}
.table-toolbar h2 { font-family: var(--font-head); font-size: 14px; font-weight: 600; }
.search-box {
  display: flex; align-items: center; gap: 8px;
  background: var(--surface2);
  border: 1px solid var(--border2);
  border-radius: 7px;
  padding: 0 10px;
  height: 34px;
  min-width: 220px;
}
.search-box svg { width: 15px; color: var(--muted); flex-shrink: 0; }
.search-box input {
  background: none; border: none; outline: none;
  color: var(--text); font-family: var(--font-body); font-size: 13px;
  width: 100%;
}
.search-box input::placeholder { color: var(--muted2); }
table { width: 100%; border-collapse: collapse; }
thead th {
  text-align: left; padding: 0.65rem 1rem;
  font-size: 11px; font-weight: 600; text-transform: uppercase;
  letter-spacing: .8px; color: var(--muted);
  border-bottom: 1px solid var(--border);
  background: var(--surface);
}
tbody tr {
  border-bottom: 1px solid var(--border);
  transition: background .1s;
}
tbody tr:last-child { border-bottom: none; }
tbody tr:hover { background: rgba(255,255,255,0.025); }
tbody td { padding: 0.7rem 1rem; font-size: 13.5px; vertical-align: middle; }
.mono { font-family: var(--font-mono); font-size: 12.5px; color: var(--muted); }

/* Badges */
.badge {
  display: inline-block;
  padding: 3px 9px;
  border-radius: 20px;
  font-size: 11px; font-weight: 500;
}
.badge-success { background: var(--success-d); color: var(--success); }
.badge-danger  { background: var(--danger-d);  color: var(--danger); }
.badge-warn    { background: var(--warn-d);    color: var(--warn); }
.badge-info    { background: var(--info-d);    color: var(--info); }
.badge-accent  { background: var(--accent-d);  color: var(--accent); }
.badge-muted   { background: rgba(255,255,255,0.06); color: var(--muted); }

/* Buttons */
.btn {
  display: inline-flex; align-items: center; gap: 6px;
  padding: 0 14px; height: 34px; border-radius: 7px;
  border: 1px solid var(--border2);
  background: var(--surface2);
  color: var(--text); font-family: var(--font-body); font-size: 13px; font-weight: 500;
  cursor: pointer; white-space: nowrap;
  transition: background .15s, border-color .15s;
  text-decoration: none;
}
.btn:hover { background: rgba(255,255,255,0.08); border-color: var(--border2); }
.btn svg { width: 15px; }
.btn-accent { background: var(--accent); color: #0e0f11; border-color: transparent; }
.btn-accent:hover { background: #b0e83e; border-color: transparent; }
.btn-danger { background: var(--danger-d); color: var(--danger); border-color: rgba(255,95,87,0.25); }
.btn-danger:hover { background: rgba(255,95,87,0.22); }
.btn-sm { height: 28px; padding: 0 10px; font-size: 12px; }

/* Action buttons in table */
.actions { display: flex; gap: 6px; }

/* Forms */
.form-card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  padding: 1.75rem;
  max-width: 720px;
}
.form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1.1rem; }
.form-grid.cols3 { grid-template-columns: 1fr 1fr 1fr; }
.form-group { display: flex; flex-direction: column; gap: 5px; }
.form-group.full { grid-column: 1 / -1; }
label { font-size: 12px; font-weight: 500; color: var(--muted); text-transform: uppercase; letter-spacing: .6px; }
input[type=text], input[type=number], input[type=date],
select, textarea {
  background: var(--surface2);
  border: 1px solid var(--border2);
  border-radius: 7px;
  color: var(--text);
  font-family: var(--font-body); font-size: 13.5px;
  padding: 0.55rem 0.85rem;
  outline: none;
  transition: border-color .15s, box-shadow .15s;
  width: 100%;
}
input:focus, select:focus, textarea:focus {
  border-color: var(--accent);
  box-shadow: 0 0 0 3px var(--accent-d);
}
textarea { resize: vertical; min-height: 80px; }
select option { background: #1e2026; }
.form-actions { display: flex; gap: 10px; margin-top: 1.5rem; }
.form-divider { height: 1px; background: var(--border); margin: 1.5rem 0; }

/* Flash message */
.flash {
  display: flex; align-items: center; gap: 10px;
  padding: 0.75rem 1.1rem;
  border-radius: 8px;
  margin-bottom: 1.25rem;
  font-size: 13.5px;
}
.flash-success { background: var(--success-d); border: 1px solid rgba(52,211,153,.25); color: var(--success); }
.flash-error   { background: var(--danger-d);  border: 1px solid rgba(255,95,87,.25);  color: var(--danger); }

/* Empty state */
.empty-state { padding: 3.5rem 1rem; text-align: center; color: var(--muted); }
.empty-state svg { width: 42px; height: 42px; margin-bottom: 12px; opacity: .35; }
.empty-state p { font-size: 13.5px; }

/* Pagination */
.pagination { display: flex; gap: 6px; align-items: center; padding: 1rem 1.25rem; border-top: 1px solid var(--border); }
.page-link {
  display: inline-flex; align-items: center; justify-content: center;
  width: 30px; height: 30px; border-radius: 6px;
  border: 1px solid var(--border2); color: var(--muted);
  font-size: 13px; cursor: pointer; transition: all .12s;
}
.page-link:hover, .page-link.active { background: var(--accent-d); color: var(--accent); border-color: transparent; }
.page-info { font-size: 12.5px; color: var(--muted); margin-left: auto; }

/* Modal */
.modal-overlay {
  display: none;
  position: fixed; inset: 0; z-index: 200;
  background: rgba(0,0,0,0.6);
  align-items: center; justify-content: center;
}
.modal-overlay.open { display: flex; }
.modal {
  background: var(--surface);
  border: 1px solid var(--border2);
  border-radius: 14px;
  width: 100%; max-width: 540px;
  padding: 1.75rem;
  position: relative;
}
.modal-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 1.25rem; }
.modal-header h3 { font-family: var(--font-head); font-size: 16px; font-weight: 700; }
.modal-close { background: none; border: none; color: var(--muted); cursor: pointer; padding: 4px; }
.modal-close:hover { color: var(--text); }

/* Scrollable table */
.table-scroll { overflow-x: auto; }

/* ── Responsive ── */
@media (max-width: 768px) {
  .sidebar { transform: translateX(-100%); }
  .main { margin-left: 0; }
  .form-grid { grid-template-columns: 1fr; }
  .form-grid.cols3 { grid-template-columns: 1fr; }
}
</style>
</head>
<body>

<!-- Sidebar -->
<aside class="sidebar">
  <div class="sidebar-logo">
    <div class="logo-mark">
      <svg viewBox="0 0 24 24" fill="none" stroke="#0e0f11" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
        <rect x="2" y="7" width="20" height="14" rx="2"/><path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2"/><line x1="12" y1="12" x2="12" y2="17"/><line x1="9.5" y1="14.5" x2="14.5" y2="14.5"/>
      </svg>
    </div>
    <span class="logo-text">Asset<span>Flow</span></span>
  </div>

  <span class="nav-section">Overview</span>
  <a href="index.php" class="nav-item <?= $currentPage==='index'?'active':'' ?>">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>
    </svg>
    Dashboard
  </a>

  <span class="nav-section">Inventory</span>
  <a href="assets.php" class="nav-item <?= $currentPage==='assets'?'active':'' ?>">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/>
      <polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/>
    </svg>
    Asset Registry
  </a>
  <a href="stock_in.php" class="nav-item <?= $currentPage==='stock_in'?'active':'' ?>">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <polyline points="8 17 12 21 16 17"/><line x1="12" y1="12" x2="12" y2="21"/>
      <path d="M20.88 18.09A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.29"/>
    </svg>
    Stock In
  </a>
  <a href="stock_out.php" class="nav-item <?= $currentPage==='stock_out'?'active':'' ?>">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <polyline points="16 7 12 3 8 7"/><line x1="12" y1="12" x2="12" y2="3"/>
      <path d="M20.88 18.09A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.29"/>
    </svg>
    Stock Out
  </a>
  <a href="categories.php" class="nav-item <?= $currentPage==='categories'?'active':'' ?>">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/>
      <line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/>
    </svg>
    Categories
  </a>

  <span class="nav-section">Reports</span>
  <a href="reports.php" class="nav-item <?= $currentPage==='reports'?'active':'' ?>">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
      <line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/>
    </svg>
    Movement Report
  </a>

  <div class="sidebar-footer">
    <div style="display:flex;align-items:center;gap:9px;margin-bottom:10px;">
      <div style="width:30px;height:30px;border-radius:50%;background:var(--accent-d);border:1.5px solid var(--accent);display:grid;place-items:center;font-size:11px;font-weight:600;color:var(--accent);flex-shrink:0;">
        <?= htmlspecialchars($userInitials) ?>
      </div>
      <div style="overflow:hidden;">
        <div style="font-size:12.5px;font-weight:500;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
          <?= htmlspecialchars($sessionUser['name']) ?>
        </div>
        <div style="font-size:11px;color:var(--muted);text-transform:capitalize;">
          <?= htmlspecialchars($sessionUser['role']) ?>
        </div>
      </div>
    </div>
    <a href="logout.php" style="display:flex;align-items:center;gap:7px;color:var(--muted);font-size:12.5px;padding:6px 4px;border-radius:6px;transition:color .15s,background .15s;text-decoration:none;"
       onmouseover="this.style.color='var(--danger)';this.style.background='var(--danger-d)'"
       onmouseout="this.style.color='var(--muted)';this.style.background='transparent'">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="14" stroke-linecap="round" stroke-linejoin="round">
        <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
        <polyline points="16 17 21 12 16 7"/>
        <line x1="21" y1="12" x2="9" y2="12"/>
      </svg>
      Sign Out
    </a>
    <div style="margin-top:8px;font-size:11px;color:var(--muted2);">AssetFlow v1.0 &nbsp;·&nbsp; © 2025</div>
  </div>
</aside>

<!-- Main -->
<div class="main">
  <div class="topbar">
    <span class="topbar-title">
      <?php
      $titles = [
        'index'      => 'Dashboard',
        'assets'     => 'Asset Registry',
        'stock_in'   => 'Stock In',
        'stock_out'  => 'Stock Out',
        'categories' => 'Categories',
        'reports'    => 'Movement Report',
        'add_asset'  => 'Add New Asset',
        'edit_asset' => 'Edit Asset',
        'add_stock_in'  => 'New Stock In',
        'add_stock_out' => 'New Stock Out',
      ];
      echo $titles[$currentPage] ?? ucfirst($currentPage);
      ?>
    </span>
    <div class="topbar-right">
      <span style="font-size:12px;color:var(--muted);"><?= date('D, M j Y') ?></span>
      <div class="topbar-user" title="<?= htmlspecialchars($sessionUser['name']) ?>">
        <?= htmlspecialchars($userInitials) ?>
      </div>
    </div>
  </div>
  <div class="page-content">
  <?php
  $flash = getFlash();
  if ($flash): ?>
    <div class="flash flash-<?= $flash['type'] === 'success' ? 'success' : 'error' ?>">
      <?= $flash['type'] === 'success'
        ? '<svg viewBox="0 0 24 24" width="16" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>'
        : '<svg viewBox="0 0 24 24" width="16" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>'
      ?>
      <?= sanitize($flash['msg']) ?>
    </div>
  <?php endif; ?>
