<?php
function generateRef(string $prefix): string {
    return strtoupper($prefix) . '-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -5));
}

function generateAssetCode(): string {
    $db  = getDB();
    $row = $db->query("SELECT MAX(CAST(SUBSTRING(asset_code, 5) AS UNSIGNED)) AS last FROM assets")->fetch();
    $next = ($row['last'] ?? 0) + 1;
    return 'AST-' . str_pad($next, 4, '0', STR_PAD_LEFT);
}

function stockBadge(int $qty, int $min): string {
    if ($qty === 0)       return '<span class="badge badge-danger">Out of Stock</span>';
    if ($qty <= $min)     return '<span class="badge badge-warn">Low Stock</span>';
    return '<span class="badge badge-success">In Stock</span>';
}

function formatMoney(float $n): string {
    return '₱ ' . number_format($n, 2);
}

function sanitize(string $v): string {
    return htmlspecialchars(trim($v), ENT_QUOTES, 'UTF-8');
}

function flash(string $type, string $msg): void {
    $_SESSION['flash'] = ['type' => $type, 'msg' => $msg];
}

function getFlash(): ?array {
    if (isset($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $f;
    }
    return null;
}
